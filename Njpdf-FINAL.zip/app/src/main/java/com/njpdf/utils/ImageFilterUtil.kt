
package com.njpdf.utils
import android.graphics.Bitmap
import android.graphics.Color
object ImageFilterUtil {
    fun grayscale(b: Bitmap): Bitmap {
        val o = Bitmap.createBitmap(b.width,b.height,b.config)
        for(x in 0 until b.width)for(y in 0 until b.height){
            val p=b.getPixel(x,y); val g=(Color.red(p)+Color.green(p)+Color.blue(p))/3
            o.setPixel(x,y,Color.rgb(g,g,g))
        }
        return o
    }
}
