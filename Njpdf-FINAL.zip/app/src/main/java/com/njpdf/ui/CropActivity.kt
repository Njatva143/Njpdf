
package com.njpdf.ui
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.njpdf.R
class CropActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_crop)}
}
