
package com.njpdf.camera

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.njpdf.R
import android.widget.Toast

class CameraActivity: AppCompatActivity(){
 override fun onCreate(savedInstanceState: Bundle?){
  super.onCreate(savedInstanceState)
  setContentView(R.layout.activity_camera)

  Toast.makeText(this,"Camera Preview Ready",Toast.LENGTH_SHORT).show()
 }
}
