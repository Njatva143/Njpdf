# Njpdf

Update 1: CameraX Scanner Module added.
