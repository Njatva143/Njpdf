# Njpdf

Update 4: OCR Module (Hindi + English)
